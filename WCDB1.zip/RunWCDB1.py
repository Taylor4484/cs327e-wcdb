# -------
# imports
# -------

import sys

from WCDB1 import wcdb1_solve

# ----
# main
# ----

wcdb1_solve(sys.stdin, sys.stdout)
